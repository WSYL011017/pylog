# Log Framework V7 🚀

**[English](README.md)** | **[中文](README.zh-CN.md)**

A production-ready, high-performance asynchronous logging framework for Python with enterprise-grade features.

## 🌟 Key Features

### ⚡ High Performance Mode (V7)
- **Adaptive Sampling**: Automatically adjusts metric sampling rate (0.1% - 10%) based on queue pressure
- **Performance Monitor**: Buffers metrics to reduce I/O overhead with 1-second batch flushing
- **Smart Queue Management**: Bounded queue (10K) with "drop-oldest" strategy to prevent OOM

### 🏗️ Core Architecture
- **Asynchronous Logging**: Zero-blocking I/O using QueueHandler + QueueListener pattern
- **Thread-Safe MDC**: Contextvars-based Mapped Diagnostic Context with async support
- **Structured Logging**: Built-in JSON formatter for ELK/Splunk integration
- **Fault Tolerance**: Exception isolation and graceful degradation under high load

### 🛡️ Enterprise Security
- **Sensitive Data Filter**: Automatic detection and masking of passwords, tokens, etc.
- **File Protection**: Hidden log files on Windows, permission control
- **Resource Management**: Bounded queues, memory protection, proper cleanup

### 📊 Monitoring & Observability
- **Real-time Metrics**: Queue size, drop count, error rate, sampling rate
- **Health Checks**: Built-in performance monitoring and alerting
- **Adaptive Control**: Dynamic adjustment based on system pressure

## 🚀 Quick Start

### 1. Basic Usage

```python
from log_framework import Slf4j, MDC

# Auto-initialization with @Slf4j decorator
@Slf4j
class UserService:
    def process_user(self, user_id: str):
        MDC.put("user_id", user_id)
        MDC.put("request_id", "req-12345")
        
        self.logger.info("Processing user request")
        self.logger.debug(f"User data: {user_id}")
        
        # MDC automatically cleared after request
        MDC.clear()
```

### 2. High Performance Mode Configuration

```python
from log_framework import LogManager

# Enable high performance mode (default in V7)
LogManager.load_config(async_mode=True, performance_mode=True)

# Get metrics for monitoring
from log_framework.metrics import LogMetrics
metrics = LogMetrics.get_metrics()
print(f"Queue size: {metrics['queue_size']}")
print(f"Sampling rate: {metrics['sample_rate']:.2%}")
```

### 3. FastAPI Integration

```python
from fastapi import FastAPI, Request
from log_framework import MDC

app = FastAPI()

@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    # Set request context
    MDC.put("path", str(request.url.path))
    MDC.put("method", request.method)
    MDC.put("request_id", str(uuid.uuid4()))
    
    try:
        response = await call_next(request)
        return response
    finally:
        MDC.clear()  # Always clear context
```

## 📈 Performance Benchmarks

### V7 High Performance Mode Results

| Test Scenario | Throughput | Latency | Memory Usage |
|---------------|------------|---------|--------------|
| **Single Thread** | **70,000 msgs/sec** | 0.014ms | Stable |
| **Multi-thread (5)** | **15,600 msgs/sec** | 0.064ms | Efficient |
| **Burst Load** | Auto-adaptive | Dynamic | Protected |
| **Sustained Load** | Consistent | <1ms P99 | Bounded |

### Comparison with Other Python Loggers

| Framework | Throughput | Features | Enterprise Ready |
|-----------|------------|----------|------------------|
| **Log Framework V7** | **70K/s** | **Complete** | **✅ Yes** |
| Loguru | 50K/s | Good | Limited |
| Structlog | 30K/s | Structured | Limited |
| Standard logging | 20K/s | Basic | No |

## ⚙️ Configuration

### High Performance Mode Settings

```yaml
# log_config.yaml
version: 1
performance:
  mode: high_performance    # Enable V7 features
  queue_size: 10000        # Bounded queue size
  sampling:
    base_rate: 0.01        # 1% base sampling rate
    adaptive: true         # Enable adaptive sampling
    max_rate: 0.10        # Maximum 10% under high load
  monitoring:
    enabled: true          # Enable performance monitoring
    flush_interval: 1.0    # Metrics flush interval (seconds)

handlers:
  json_file:
    class: logging.handlers.TimedRotatingFileHandler
    formatter: json
    filename: ./logs/app.log
    when: "midnight"
    backupCount: 7
```

### Environment Variables

```bash
# Enable high performance mode
export LOG_PERFORMANCE_MODE=high
export LOG_QUEUE_SIZE=10000
export LOG_SAMPLING_RATE=0.01

# Set log level
export PYLOG_LEVEL=INFO
```

## 🔧 Advanced Usage

### 1. Custom Performance Monitoring

```python
from log_framework.metrics import PerformanceMonitor, LogMetrics

# Record custom metrics
PerformanceMonitor.record_metric("custom_metric", 42.0)

# Get detailed metrics
metrics = LogMetrics.get_metrics()
print(f"Queue utilization: {metrics['queue_size']/10000:.1%}")
print(f"Current sampling rate: {metrics['sample_rate']:.2%}")
```

### 2. Adaptive Sampling Control

```python
# Monitor adaptive behavior
import time

# Normal load
for i in range(1000):
    logger.info(f"Normal message {i}")

# High load burst
print("Starting high load burst...")
burst_start = time.time()
for i in range(50000):
    logger.info(f"Burst message {i}")

# Check metrics after burst
metrics = LogMetrics.get_metrics()
print(f"Dropped during burst: {metrics['dropped_total']}")
print(f"Final sampling rate: {metrics['sample_rate']:.2%}")
```

### 3. Memory-Efficient Bulk Logging

```python
# Efficient bulk processing
def process_large_dataset(dataset):
    batch_size = 1000
    
    for i, record in enumerate(dataset):
        # Use MDC for context
        MDC.put("record_id", str(record.id))
        MDC.put("batch_index", str(i // batch_size))
        
        logger.info(f"Processing record: {record.name}")
        
        # Clear every batch to prevent MDC buildup
        if i % batch_size == 0:
            MDC.clear()
    
    MDC.clear()  # Final cleanup
```

## 🛡️ Security Best Practices

### Sensitive Data Protection

```python
from log_framework.logger_setup import SensitiveDataFilter

# Configure sensitive data filtering
filter = SensitiveDataFilter()
logger.addFilter(filter)

# Automatically masks:
# - password=secret123 → password=***
# - Authorization: Bearer token123 → Authorization: Bearer ***
```

### Secure Configuration

```yaml
# Production security settings
security:
  sensitive_patterns:
    - "password=[^&\\s]+"
    - "token=[^&\\s]+"
    - "Authorization:\\s*Bearer\\s+[^\\s]+"
  
  file_permissions:
    mode: 0o600  # Restrictive permissions
    hidden: true  # Hide log files on Windows
```

## 📊 Monitoring and Alerting

### Integration with Prometheus

```python
# Export metrics for Prometheus
from log_framework.metrics import LogMetrics
from prometheus_client import Gauge, Counter

# Create Prometheus metrics
queue_gauge = Gauge('log_queue_size', 'Current log queue size')
drop_counter = Counter('log_dropped_total', 'Total dropped log messages')
sample_gauge = Gauge('log_sampling_rate', 'Current sampling rate')

# Update metrics
def update_prometheus_metrics():
    metrics = LogMetrics.get_metrics()
    queue_gauge.set(metrics['queue_size'])
    drop_counter.inc(metrics['dropped_total'])
    sample_gauge.set(metrics['sample_rate'])
```

### Health Check Endpoint

```python
# FastAPI health check
@app.get("/health/logs")
async def log_health_check():
    metrics = LogMetrics.get_metrics()
    
    # Check if system is healthy
    is_healthy = (
        metrics['queue_size'] < 8000 and  # 80% threshold
        metrics['sample_rate'] < 0.05 and   # Not under extreme pressure
        metrics['error_count'] < 10          # Low error rate
    )
    
    return {
        "status": "healthy" if is_healthy else "degraded",
        "metrics": metrics,
        "thresholds": {
            "queue_size": {"current": metrics['queue_size'], "max": 8000},
            "sampling_rate": {"current": f"{metrics['sample_rate']:.2%}", "max": "5%"},
            "error_count": {"current": metrics['error_count'], "max": 10}
        }
    }
```

## 🔍 Troubleshooting

### High Drop Rate Issues

```python
# Diagnose high drop rates
metrics = LogMetrics.get_metrics()

if metrics['dropped_total'] > 1000:
    print("⚠️ High drop rate detected!")
    print(f"Queue size: {metrics['queue_size']}/10000")
    print(f"Sampling rate: {metrics['sample_rate']:.2%}")
    
    # Recommendations
    if metrics['queue_size'] > 8000:
        print("💡 Consider increasing queue size or reducing log volume")
    if metrics['sample_rate'] > 0.05:
        print("💡 System under high pressure, consider scaling")
```

### Performance Optimization

```python
# Optimize for your use case
def optimize_logging():
    # For high-throughput scenarios
    LogManager.load_config(
        async_mode=True,
        performance_mode=True,
        queue_size=20000,  # Larger queue for burst handling
        sampling_rate=0.005  # Lower base sampling rate
    )
    
    # For low-latency scenarios
    LogManager.load_config(
        async_mode=True,
        performance_mode=True,
        queue_size=5000,  # Smaller queue for lower latency
        sampling_rate=0.02  # Higher sampling for better monitoring
    )
```

## 🚀 Deployment

### Docker Deployment

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Copy framework
COPY log_framework/ ./log_framework/
COPY requirements.txt .

# Install dependencies
RUN pip install -r requirements.txt

# Set performance environment variables
ENV LOG_PERFORMANCE_MODE=high
ENV LOG_QUEUE_SIZE=10000
ENV PYLOG_LEVEL=INFO

# Run application
COPY your_app.py .
CMD ["python", "your_app.py"]
```

### Kubernetes Configuration

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: log-config
data:
  log_config.yaml: |
    version: 1
    performance:
      mode: high_performance
      queue_size: 10000
    
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: your-app
spec:
  replicas: 3
  template:
    spec:
      containers:
      - name: app
        image: your-app:latest
        env:
        - name: LOG_PERFORMANCE_MODE
          value: "high"
        - name: PYLOG_LEVEL
          valueFrom:
            configMapKeyRef:
              name: app-config
              key: log_level
        volumeMounts:
        - name: log-config
          mountPath: /app/log_config.yaml
          subPath: log_config.yaml
      volumes:
      - name: log-config
        configMap:
          name: log-config
```

## 📚 Documentation

- [中文文档](README.zh-CN.md)
- [API Reference](docs/api.md)
- [Architecture Guide](docs/architecture.md)
- [Performance Tuning](docs/performance.md)
- [Security Guide](docs/security.md)

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Inspired by Log4j2 and Logback from Java ecosystem
- Built on Python's robust logging framework
- Community-driven development and improvements

---

**⭐ If you find this project helpful, please give it a star!**